#ifndef FIXEDINT_H_INCLUDED
#define FIXEDINT_H_INCLUDED

#include <cstdint>

typedef std::uint64_t u64;
typedef std::int64_t i64;
typedef std::int32_t i32;

#endif
